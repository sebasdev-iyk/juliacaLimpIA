/**
 * Servicio de análisis de imágenes con IA.
 * Cadena de intentos:
 *   1. YOLO-World (microservicio Python localhost:8000)
 *   2. Fallback: fakeImageAnalyzer (simulación)
 */

import { fakeImageAnalyzer } from '../utils/fakeImageAnalyzer'

const AI_SERVICE_URL = 'http://localhost:8000'
const TIMEOUT_MS = 8000

/**
 * Analiza una imagen con el servicio AI.
 * @param {File|null} imageFile - Archivo de imagen a analizar
 * @param {string|null} manualLevel - Nivel manual (Bajo/Medio/Crítico)
 * @returns {Promise<object>} Resultado del análisis
 */
export async function analyzeImage(imageFile, manualLevel = null) {
  // Si el usuario eligió nivel manual, respetarlo
  if (manualLevel) {
    return buildManualResult(manualLevel)
  }

  // Intentar API real primero
  if (imageFile) {
    try {
      const result = await tryApiAnalysis(imageFile)
      if (result) return result
    } catch (e) {
      console.warn('API AI no disponible, usando simulación:', e.message)
    }
  }

  // Fallback: usar fakeImageAnalyzer
  const simulated = trySimulatedAnalysis(imageFile)
  simulated.fallback_simulado = true
  return simulated
}

/**
 * Intenta llamar al microservicio YOLO-World.
 */
async function tryApiAnalysis(imageFile) {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS)

  try {
    const formData = new FormData()
    formData.append('file', imageFile)

    const response = await fetch(`${AI_SERVICE_URL}/analyze`, {
      method: 'POST',
      body: formData,
      signal: controller.signal,
    })

    clearTimeout(timeout)

    if (!response.ok) {
      throw new Error(`API responded with ${response.status}`)
    }

    const data = await response.json()

    return {
      basura_detectada: data.basura_detectada,
      nivel: data.nivel,
      confianza: data.confianza,
      prioridad: data.prioridad,
      resumen: data.resumen,
      objetos: data.objetos || [],
      metodo: data.metodo || 'YOLO-World',
      es_real: true,
    }
  } catch (e) {
    clearTimeout(timeout)
    throw e
  }
}

/**
 * Obtiene la imagen con bounding boxes del servicio AI.
 * @param {File} imageFile
 * @returns {Promise<{url: string, detections: number, severity: string}|null>}
 */
export async function getAnnotatedImage(imageFile) {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS)

  try {
    const formData = new FormData()
    formData.append('file', imageFile)

    const response = await fetch(`${AI_SERVICE_URL}/analyze-with-image`, {
      method: 'POST',
      body: formData,
      signal: controller.signal,
    })

    clearTimeout(timeout)

    if (!response.ok) return null

    const blob = await response.blob()
    const url = URL.createObjectURL(blob)

    return {
      url,
      detections: parseInt(response.headers.get('X-Detections') || '0'),
      severity: response.headers.get('X-Severity') || 'Bajo',
      confidence: response.headers.get('X-Confidence') || '0%',
    }
  } catch {
    clearTimeout(timeout)
    return null
  }
}

/**
 * Fallback: análisis simulado con fakeImageAnalyzer.
 */
function trySimulatedAnalysis(imageFile) {
  const analysis = fakeImageAnalyzer(imageFile, null)
  return {
    ...analysis,
    metodo: 'Simulado',
    resumen: `Nivel ${analysis.nivel} (simulación)`,
    es_real: false,
  }
}

function buildManualResult(level) {
  const confidences = { Crítico: '92%', Medio: '84%', Bajo: '76%' }
  return {
    basura_detectada: true,
    nivel: level,
    confianza: confidences[level] || '80%',
    prioridad: level === 'Crítico' ? 'Alta' : level === 'Medio' ? 'Media' : 'Baja',
    resumen: `Nivel ${level} (selección manual)`,
    metodo: 'Manual',
    es_real: false,
  }
}
