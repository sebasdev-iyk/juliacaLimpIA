import { Gauge, AlertTriangle, MapPin, TrendingDown } from 'lucide-react'

export default function StatsCards({ stats }) {
  const cards = [
    {
      icon: MapPin,
      label: 'Reportes totales',
      value: stats.total,
      color: '#059669',
      bg: '#d1fae5',
    },
    {
      icon: AlertTriangle,
      label: 'Puntos críticos',
      value: stats.critical,
      color: '#ef4444',
      bg: '#fee2e2',
      pulse: true,
    },
    {
      icon: Gauge,
      label: 'Distancia',
      value: stats.distance > 0 ? `${stats.distance} km` : '—',
      color: '#2563eb',
      bg: '#dbeafe',
    },
    {
      icon: TrendingDown,
      label: 'Ahorro',
      value: stats.savings > 0 ? `${stats.savings}%` : '—',
      color: '#059669',
      bg: '#d1fae5',
    },
  ]

  return (
    <div className="stats-scroll hide-scrollbar">
      {cards.map((card, i) => (
        <div
          key={card.label}
          className={`stats-card ${card.pulse ? 'stats-card-pulse' : ''}`}
          style={{
            background: 'white',
            borderRadius: 10,
            padding: '8px 14px',
            border: '1px solid #e2e8f0',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            minWidth: 140,
            flexShrink: 0,
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 8,
              background: card.bg,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <card.icon size={16} color={card.color} />
          </div>
          <div>
            <div
              style={{
                fontSize: 16,
                fontWeight: 700,
                lineHeight: 1.2,
                color: card.pulse ? card.color : undefined,
              }}
            >
              {card.value}
            </div>
            <div style={{ fontSize: 10, color: '#64748b', whiteSpace: 'nowrap' }}>
              {card.label}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
