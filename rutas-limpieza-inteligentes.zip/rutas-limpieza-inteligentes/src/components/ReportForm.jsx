import { useState, useRef } from 'react'
import { ZONES, ZONE_COORDS } from '../data/mockReports'
import { analyzeImage, getAnnotatedImage } from '../services/aiAnalyzer'

const LEVEL_COLORS = {
  Crítico: { bg: '#fef2f2', border: '#fecaca', badge: '#ef4444', text: '#991b1b' },
  Medio: { bg: '#fffbeb', border: '#fde68a', badge: '#eab308', text: '#854d0e' },
  Bajo: { bg: '#f0fdf4', border: '#bbf7d0', badge: '#22c55e', text: '#166534' },
}

export default function ReportForm({ onAddReport, onClose }) {
  const [image, setImage] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [annotatedUrl, setAnnotatedUrl] = useState(null)
  const [desc, setDesc] = useState('')
  const [zone, setZone] = useState(ZONES[0])
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const fileInputRef = useRef(null)

  const handleImage = (e) => {
    const file = e.target.files[0]
    if (file) {
      setImage(file)
      setImagePreview(URL.createObjectURL(file))
      setAnnotatedUrl(null)
      setResult(null)
    }
  }

  const useTestImage = () => {
    const images = [
      { name: 'basura-critico-01.jpg', label: 'Crítico' },
      { name: 'residuos-medio-02.jpg', label: 'Medio' },
      { name: 'papeles-bajo-03.jpg', label: 'Bajo' },
    ]
    const pick = images[Math.floor(Math.random() * images.length)]
    const blob = new Blob(['fake'], { type: 'image/jpeg' })
    const file = new File([blob], pick.name, { type: 'image/jpeg' })
    setImage(file)
    setImagePreview(null)
    setAnnotatedUrl(null)
    setResult(null)
  }

  const handleAnalyze = async () => {
    if (!image) {
      alert('Sube una imagen primero')
      return
    }

    setAnalyzing(true)
    setResult(null)
    setAnnotatedUrl(null)

    // Intentar obtener imagen anotada (con bounding boxes)
    getAnnotatedImage(image).then(annotated => {
      if (annotated) {
        setAnnotatedUrl(annotated.url)
      }
    }).catch(() => {})

    // Análisis principal
    const analysis = await analyzeImage(image, null)
    setResult(analysis)
    setAnalyzing(false)
  }

  const handleSubmit = () => {
    if (!result) {
      alert('Analiza la imagen primero')
      return
    }

    const coords = ZONE_COORDS[zone] || { lat: -15.84, lng: -70.02 }

    const newReport = {
      id: Date.now(),
      zona: zone,
      descripcion: desc || 'Reporte ciudadano',
      latitud: coords.lat + (Math.random() - 0.5) * 0.004,
      longitud: coords.lng + (Math.random() - 0.5) * 0.004,
      nivel: result.nivel,
      confianza: result.confianza,
      prioridad: result.prioridad,
      estado: 'Pendiente',
      imagen: '📸',
      fecha: new Date().toLocaleDateString('es-PE'),
    }

    onAddReport(newReport)

    // Reset
    setImage(null)
    setImagePreview(null)
    setAnnotatedUrl(null)
    setDesc('')
    setResult(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const handleQuickAdd = (level) => {
    const coords = ZONE_COORDS[zone] || { lat: -15.84, lng: -70.02 }
    const report = {
      id: Date.now() + Math.random(),
      zona: zone,
      descripcion: desc || `Reporte ${level}`,
      latitud: coords.lat + (Math.random() - 0.5) * 0.004,
      longitud: coords.lng + (Math.random() - 0.5) * 0.004,
      nivel: level,
      confianza: level === 'Crítico' ? '91%' : level === 'Medio' ? '82%' : '75%',
      prioridad: level === 'Crítico' ? 'Alta' : level === 'Medio' ? 'Media' : 'Baja',
      estado: 'Pendiente',
      imagen: '📸',
      fecha: new Date().toLocaleDateString('es-PE'),
    }
    onAddReport(report)
    setDesc('')
  }

  const colors = result ? LEVEL_COLORS[result.nivel] || LEVEL_COLORS.Bajo : null

  return (
    <div className="report-form-content">
      <h3 className="report-form-title">📸 Nuevo reporte</h3>

      {/* Subir imagen / Preview con bounding boxes */}
      <div
        onClick={() => !analyzing && fileInputRef.current?.click()}
        className="report-form-image-upload"
        style={{
          backgroundImage: annotatedUrl
            ? `url(${annotatedUrl})`
            : imagePreview
              ? `url(${imagePreview})`
              : undefined,
        }}
      >
        {!imagePreview && !annotatedUrl && (
          <>
            <span className="report-form-image-icon">📷</span>
            <span className="report-form-image-label">Subir foto</span>
          </>
        )}
        {(imagePreview || annotatedUrl) && (
          <div className="report-form-image-overlay">
            {annotatedUrl ? '✅ Con bounding boxes' : 'Cambiar imagen'}
          </div>
        )}
        {/* Badge del método */}
        {result && !analyzing && (
          <div className={`report-form-badge ${result.es_real ? 'badge-real' : 'badge-sim'}`}>
            {result.metodo || (result.es_real ? 'YOLO-World' : 'Simulado')}
          </div>
        )}
        {/* Warning de simulación */}
        {result && result.fallback_simulado && (
          <div className="report-form-warning">
            ⚠️ Servidor AI no disponible — resultado simulado
          </div>
        )}
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleImage}
        style={{ display: 'none' }}
      />

      {/* Test image button */}
      <button
        onClick={useTestImage}
        className="report-form-test-btn"
      >
        🎲 Usar imagen de prueba
      </button>

      {/* Descripción */}
      <textarea
        value={desc}
        onChange={e => setDesc(e.target.value)}
        placeholder="Descripción del reporte..."
        className="report-form-textarea"
        rows={3}
      />

      {/* Zona */}
      <select
        value={zone}
        onChange={e => setZone(e.target.value)}
        className="report-form-select"
      >
        {ZONES.map(z => (
          <option key={z} value={z}>{z}</option>
        ))}
      </select>

      {/* Botón Analizar */}
      {!result && !analyzing && (
        <button
          onClick={handleAnalyze}
          className="report-form-btn report-form-btn-analyze"
          disabled={!image}
        >
          🤖 Analizar con IA
        </button>
      )}

      {/* Analizando */}
      {analyzing && (
        <div className="report-form-analyzing">
          <div className="report-form-spinner" />
          <div>Analizando con YOLO-World...</div>
        </div>
      )}

      {/* Resultado del análisis */}
      {result && !analyzing && (
        <>
          <div
            className="report-form-result"
            style={{
              background: colors.bg,
              border: `1px solid ${colors.border}`,
            }}
          >
            {/* Header */}
            <div className="report-form-result-header">
              <span style={{ fontSize: 14, fontWeight: 600 }}>
                {result.es_real ? '🧠' : '⚙️'} Análisis completo
              </span>
              <span
                className="report-form-result-badge"
                style={{
                  background: colors.badge,
                  color: 'white',
                }}
              >
                {result.nivel}
              </span>
            </div>

            {/* Métricas principales */}
            <div className="report-form-metrics">
              <div><span className="metric-label">Basura:</span> <strong>{result.basura_detectada ? 'Sí' : 'No'}</strong></div>
              <div><span className="metric-label">Confianza:</span> <strong>{result.confianza}</strong></div>
              <div><span className="metric-label">Prioridad:</span> <strong style={{ color: colors.badge }}>{result.prioridad}</strong></div>
              <div><span className="metric-label">Método:</span> <strong>{result.metodo}</strong></div>
            </div>

            {/* Resumen */}
            {result.resumen && (
              <div className="report-form-resumen">
                {result.resumen}
              </div>
            )}

            {/* Lista de objetos detectados */}
            {result.objetos && result.objetos.length > 0 && (
              <div style={{ marginTop: 8 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#64748b', marginBottom: 4 }}>
                  Objetos detectados ({result.objetos.length})
                </div>
                {result.objetos.map((obj, i) => (
                  <div key={i} style={{
                    display: 'flex', justifyContent: 'space-between',
                    padding: '4px 8px', borderRadius: 4,
                    background: i % 2 === 0 ? 'rgba(255,255,255,0.4)' : 'transparent',
                    fontSize: 13,
                  }}>
                    <span style={{ fontWeight: 500 }}>{obj.clase}</span>
                    <span style={{ color: '#64748b' }}>{(obj.confianza * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Botón agregar */}
          <button
            onClick={handleSubmit}
            className="report-form-btn report-form-btn-submit"
          >
            📍 Agregar reporte al mapa
          </button>
        </>
      )}

      {/* Separador */}
      <div className="report-form-divider">
        <span>o agrega rápido</span>
      </div>

      {/* Botones de agregado rápido */}
      <div className="report-form-quick-add">
        {[
          { level: 'Crítico', color: '#ef4444', bg: '#fee2e2' },
          { level: 'Medio', color: '#eab308', bg: '#fef9c3' },
          { level: 'Bajo', color: '#22c55e', bg: '#d1fae5' },
        ].map(item => (
          <button
            key={item.level}
            onClick={() => handleQuickAdd(item.level)}
            className="report-form-quick-btn"
            style={{
              background: item.bg,
              color: item.color,
            }}
          >
            + {item.level}
          </button>
        ))}
      </div>
    </div>
  )
}
